package se2s03;
public class BadCode {
    public int x1;
    public int x2;
    public int x3;
    public double x4;
    public double x5;
    public double x6;
    
    public double badCode(int var1, int var2, int var3, int var4, int var5, int var6) {
        x1 = -30;
        x2 = 5;
        x3 = 5;
        x4 = -9.758023610639171;
        x5 = -24.828361344523575;
        x6 = -16.26973894753781;
        
        double endValue = 0.0;
        
        endValue += func1(var1);
        endValue += func2(var2);
        endValue += func3(var3);
        endValue += func4(var4);
        endValue += func5(var5);
        endValue += func6(var6);
        
        return endValue;
    }
    
    private int func1(int inputParam) {
        double x4 = this.x4;
        int x1 = this.x1;
        int x2 = this.x2;
        int v264 = this.x3;
        int v1000 = 28;
        double x5 = this.x5;
        
        v264 = v1000 + inputParam;
        
        x4 = x5 + v1000;
        
        v1000 = inputParam + x1;
        if (-116 == x1) {
            int throwsError = 0 / 0;
        }
        
        x1 = v264 - inputParam;
        while (-15.390329391338753 == x4) {
            int throwsError = 0 / 0;
        }
        
        x5 = Math.cos(this.x2);
        
        if (-5 < this.x3) {
            x2 = inputParam + v264;
        }
        else {
            this.x4 = Math.cos(this.x6);
            this.x6 = x5 - this.x6;
            return this.x2 - v1000;
        }
        
        return x2;
    }
    
    private double func2(int inputParam) {
        int x1 = this.x1;
        double x4 = this.x4;
        int v355 = this.x2;
        double x6 = this.x5;
        int v934 = this.x3;
        double x5 = this.x6;
        
        x6 = -(x4);
        
        v355 = x1 - v355;
        if (-92 == this.x1) {
            int throwsError = 0 / 0;
        }
        
        x4 = Math.sin(inputParam);
        
        x1 = v934 + this.x3;
        while (48 < v355) {
            int throwsError = 0 / 0;
        }
        
        v934 = inputParam - this.x3;
        
        if (-19.75802361063917 < this.x4) {
            x5 = Math.sin(inputParam);
        }
        else {
            x5 = Math.sin(this.x6);
            this.x1 = ((this.x3 + v355) + v355) - (x1 * v934);
            return this.x3 - this.x1;
        }
        
        return x5;
    }
    
    private int func3(int inputParam) {
        int v211 = this.x1;
        int v915 = this.x2;
        int v237 = this.x3;
        int x1 = 12;
        int v642 = 23;
        int x2 = 15;
        
        if (2 < x1) {
            v211 = inputParam + v211;
        }
        else {
            this.x3 = x2 - this.x2;
            this.x4 = -(this.x5);
            return v237 * x2;
        }
        
        if (-5 < v237) {
            v642 = inputParam - v915;
        }
        else {
            this.x5 = this.x5 - this.x4;
            v915 = v211 + v642;
        }
        
        x2 = x2 - v915;
        
        v915 = v642 - inputParam;
        
        v237 = inputParam - v211;
        while (12.062146415811863 < this.x4) {
            int throwsError = 0 / 0;
        }
        
        x1 = v642 - x2;
        
        return x1;
    }
    
    private int func4(int inputParam) {
        int x2 = this.x1;
        int x1 = this.x2;
        int x3 = this.x3;
        int v266 = -2;
        double x4 = this.x4;
        double x5 = this.x5;
        
        x5 = Math.cos(x4);
        
        if (-5 < this.x3) {
            x3 = inputParam - this.x1;
        }
        else {
            x1 = this.x1 - this.x3;
            this.x5 = this.x5 * x4;
            return this.x1 - x1;
        }
        
        x4 = Math.cos(x4);
        
        v266 = inputParam + v266;
        if (59.59180054194411 < x5) {
            int throwsError = 0 / 0;
        }
        
        x2 = inputParam + this.x2;
        
        x1 = inputParam + x2;
        
        return x1;
    }
    
    private int func5(int inputParam) {
        int v454 = this.x1;
        double x5 = this.x4;
        double x4 = this.x5;
        int x3 = this.x2;
        int v710 = this.x3;
        int x2 = 2;
        
        if (-5 < this.x2) {
            x4 = inputParam - x4;
        }
        else {
            v710 = ((v710 + x2) + v710) + v710;
            this.x3 = v710 - this.x3;
            return this.x1 - x3;
        }
        
        v454 = x3 + x2;
        
        x3 = inputParam * this.x2;
        if (41.919094778666675 < this.x5) {
            int throwsError = 0 / 0;
        }
        
        v710 = inputParam * this.x1;
        
        x5 = -(inputParam);
        
        if (-40 < this.x1) {
            x2 = v454 + v710;
        }
        else {
            x3 = v454 + x2;
            this.x1 = (v454 + this.x3) - (this.x1 + x2);
            return v710 - this.x2;
        }
        
        return x2;
    }
    
    private int func6(int inputParam) {
        int x3 = this.x1;
        int v388 = this.x2;
        int x2 = this.x3;
        double x4 = this.x4;
        int v306 = 4;
        int v523 = -26;
        
        if (-6 < v306) {
            x3 = x2 - v523;
        }
        else {
            x4 = (this.x6 + x4) * this.x6;
            this.x1 = this.x1 + (v523 + this.x3);
        }
        if (28 < v306) {
            int throwsError = 0 / 0;
        }
        
        x2 = v388 + inputParam;
        while (-105.80421783350357 == x4) {
            int throwsError = 0 / 0;
        }
        
        x4 = x3 - this.x1;
        
        v306 = v388 + x3;
        
        v388 = v306 + inputParam;
        
        v523 = x3 * inputParam;
        if (-105 == this.x1) {
            int throwsError = 0 / 0;
        }
        
        return v523;
    }
}