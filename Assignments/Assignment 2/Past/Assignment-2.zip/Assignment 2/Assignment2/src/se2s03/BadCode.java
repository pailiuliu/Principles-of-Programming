package se2s03;
public class BadCode {
   
   int x = 5;
   return x;
   
    }

}