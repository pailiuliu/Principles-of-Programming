package se2s03;
public class BadCode {

public double badCode(int var1, int var2, int var3, int var4, int var5, int var6) {

return (2*var1 + 28+Math.sin(var2)+var3 - 15 + 2*var4+5 + 7+var5*-30 + 31*var6) ;
}

}