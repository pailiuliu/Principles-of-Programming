public class Cube {
	private double sideLength;

	public Cube(double sideLength) {
		this.sideLength = sideLength;
	}

	public double getSideLength() {
		return this.sideLength;
	}

	public void setSideLength(double sideLength) {
		this.sideLength = sideLength;
	}

	// Length * Width
	public double faceArea() {
		return (this.sideLength * this.sideLength);
	}

	// 6 * Length * Width (6 Sides)
	public double surfaceArea() {
		return (6 * this.faceArea());
	}

	// Length * Width * Height
	public double volume() {
		return (this.sideLength * this.sideLength * this.sideLength);
	}
}